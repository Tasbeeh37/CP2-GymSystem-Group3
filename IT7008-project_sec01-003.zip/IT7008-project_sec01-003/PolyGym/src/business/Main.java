package business;

import GUI.MainMenu;

/**
 * Entry point for the PolyFit Gym management application.
 * This class loads the saved system state, seeds startup data when needed,
 * and opens the main Swing menu on the event dispatch thread.
 *
 * @version 5.0
 * @author Tasbeeh
 */
public class Main {

    /**
     * Starts the application.
     *
     * @param args command-line arguments passed to the program (currently unused)
     */
    public static void main(String[] args) {
        // 1. Try loading a previously serialized system state session
        GymSystem gym = FileHandler.loadSystem();

        // 2. If it is a fresh launch, instantiate a clean engine and populate from startup.txt
        if (gym == null) {
            gym = new GymSystem();
            StartupLoader.loadFromFile(gym);
        }

        // 3. Launch the user interface safely on the Swing Event Dispatch Thread
        final GymSystem finalizedSystemReference = gym;
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainMenu(finalizedSystemReference).setVisible(true);
            }
        });
    }
    
}
