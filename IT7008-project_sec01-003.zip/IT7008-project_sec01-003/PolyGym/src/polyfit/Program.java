package polyfit;

/**
 * Compatibility shim for older launch configurations that still reference polyfit.Program.
 */
public class Program {
    public static void main(String[] args) {
        business.Main.main(args);
    }
}
