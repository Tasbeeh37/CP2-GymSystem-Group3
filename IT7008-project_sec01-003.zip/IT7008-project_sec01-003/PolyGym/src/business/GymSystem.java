package business;

import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 * Core Controller Class managing Gym operations and processing data logic rules.
 * Aligned with project requirements Req-15 and Req-16.
 * * @author Tasbeeh
 */
public class GymSystem implements Reportable, Serializable {
    private static final long serialVersionUID = 1L;

    public static void validateName(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be empty.");
        }
        String trimmed = value.trim();
        if (trimmed.length() < 2 || trimmed.matches(".*\\s{2,}.*") || !trimmed.matches("[A-Za-z][A-Za-z' -]*")) {
            throw new IllegalArgumentException(fieldName + " must contain at least 2 letters and no repeated spaces or invalid characters.");
        }
        if (trimmed.replaceAll("[^A-Za-z]", "").length() < 2) {
            throw new IllegalArgumentException(fieldName + " must contain at least 2 alphabetic characters.");
        }
    }
//validatePhoneNumber
    public static void validatePhoneNumber(String phone) {
        if (phone == null || !phone.trim().matches("\\d{8,15}")) {
            throw new IllegalArgumentException("Phone number must contain only digits and be between 8 and 15 characters long.");
        }
    }
//validateAddress
    public static void validateAddress(String address) {
        if (address == null || address.trim().length() < 5) {
            throw new IllegalArgumentException("Address must contain at least 5 meaningful characters.");
        }
    }

    public static void validateDescription(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be empty.");
        }
        String trimmed = value.trim();
        if (trimmed.length() < 3 || trimmed.matches(".*\\s{2,}.*")) {
            throw new IllegalArgumentException(fieldName + " must be at least 3 characters long and must not contain repeated spaces.");
        }
        if (trimmed.replaceAll("[^A-Za-z]", "").length() < 3) {
            throw new IllegalArgumentException(fieldName + " must contain at least 3 alphabetic characters.");
        }
    }

    public static void validateDateOfBirth(String dob) {
        if (dob == null || !dob.trim().matches("\\d{2}/\\d{2}/\\d{4}")) {
            throw new IllegalArgumentException("Date of birth must use the format DD/MM/YYYY.");
        }
    }

    public static double parseSalary(String salaryText) {
        try {
            double salary = Double.parseDouble(salaryText.trim());
            if (salary < 0) {
                throw new IllegalArgumentException("Salary cannot be negative.");
            }
            return salary;
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Salary must be a valid number.");
        }
    }

    private ArrayList<Employee> employees;
    private ArrayList<Member> members;
    private int nextMemberId;
    private int nextStaffId;

    public GymSystem() {
        this.employees = new ArrayList<Employee>();
        this.members = new ArrayList<Member>();
        this.nextMemberId = 1;
        this.nextStaffId = 1;
    }

    // Accessors for Collections
    public ArrayList<Employee> getEmployees() { 
        return employees; 
    }
    
    public ArrayList<Member> getMembers() { 
        return members; 
    }

    // ID Sequence Tracking Management
    public int getNextMemberId() { 
        return nextMemberId; 
    }
    
    public int getNextStaffId() { 
        return nextStaffId; 
    }

    // --- Employee Core Logic Operations ---
    
    /**
     * Fixed Method to safely instantiate and add employees/trainers.
     * Rearranged parameter mapping sequence to match specific constructor designs.
     */
    public Employee addEmployee(int id, String fn, String ln, String ad, String ph, double salary, boolean isTrainer) {
        // Req-15: Ensure parameters do not accept empty values or invalid logic states
        validateName(fn, "First name");
        validateName(ln, "Last name");
        validateAddress(ad);
        validatePhoneNumber(ph);
        if (salary < 0) {
            throw new IllegalArgumentException("Base salary values cannot be negative.");
        }

        Employee emp;
        if (isTrainer) {
            // FIXED: Salary is passed as the second argument to match PersonalTrainer constructor layout
            emp = new PersonalTrainer(id, salary, fn, ln, ad, ph);
        } else {
            // FIXED: Salary is passed as the second argument to match Employee constructor layout
            emp = new Employee(id, salary, fn, ln, ad, ph);
        }
        
        employees.add(emp);
        nextStaffId++; // Safely advance tracking sequences
        return emp;
    }

    public Employee findEmployeeById(int id) {
        for (Employee e : employees) {
            if (e.getStaffId() == id) return e;
        }
        return null;
    }

    public void deleteEmployee(int id) {
        Employee emp = findEmployeeById(id);
        if (emp != null) {
            if (emp instanceof PersonalTrainer && !canDeleteTrainer(id)) {
                throw new IllegalStateException("Cannot delete a Personal Trainer who still has assigned members.");
            }
            employees.remove(emp);
        }
    }

    // --- Member Core Logic Operations ---
    
    /**
     * Directly links dynamic sub-typed PolyStudent records to the master registry.
     */
    public Member addPolyStudent(int memberId, String dob, String gender, String course, String team, String fn, String ln, String ad, String ph) {
        validateName(fn, "First name");
        validateName(ln, "Last name");
        validateDateOfBirth(dob);
        validateAddress(ad);
        validatePhoneNumber(ph);
        validateDescription(course, "Course");
        
        Member m = new PolyStudent(memberId, dob, gender, course, team, fn, ln, ad, ph);
        members.add(m);
        nextMemberId++;
        return m;
    }

    /**
     * Directly links dynamic sub-typed PolyStaff records to the master registry.
     */
    public Member addPolyStaff(int memberId, String dob, String gender, String position, String dept, String fn, String ln, String ad, String ph) {
        validateName(fn, "First name");
        validateName(ln, "Last name");
        validateDateOfBirth(dob);
        validateAddress(ad);
        validatePhoneNumber(ph);
        validateDescription(position, "Position");
        validateDescription(dept, "Department");
        
        Member m = new PolyStaff(memberId, dob, gender, position, dept, fn, ln, ad, ph);
        members.add(m);
        nextMemberId++;
        return m;
    }

    public Member findMemberById(int id) {
        for (Member m : members) {
            if (m.getMemberId() == id) return m;
        }
        return null;
    }

    public void deleteMember(int id) {
        Member m = findMemberById(id);
        if (m != null) {
            // Cleanly sever assigned personal training relationships prior to object deletion
            if (m.getTrainer() != null) {
                m.getTrainer().removeMember(m);
            }
            members.remove(m);
        }
    }

    // --- Personal Trainer Assignment Relationships Logic ---
    public void assignTrainer(int memberId, int trainerId) {
        Member m = findMemberById(memberId);
        Employee e = findEmployeeById(trainerId);
        
        if (m == null) {
            throw new IllegalArgumentException("Assignment failed: Member ID does not exist.");
        }
        if (e == null || !(e instanceof PersonalTrainer)) {
            throw new IllegalArgumentException("Assignment failed: Trainer ID does not match an active Personal Trainer profile.");
        }

        PersonalTrainer pt = (PersonalTrainer) e;
        
        // Remove from current trainer if already assigned somewhere else
        if (m.getTrainer() != null) {
            m.getTrainer().removeMember(m);
        }
        
        m.setTrainer(pt);
        pt.addMember(m);
    }

    public void removeTrainer(int memberId) {
        Member m = findMemberById(memberId);
        if (m != null && m.getTrainer() != null) {
            m.getTrainer().removeMember(m);
            m.setTrainer(null);
        }
    }

    // Helper utility method to get only employees who are Personal Trainers
    public ArrayList<PersonalTrainer> getTrainers() {
        ArrayList<PersonalTrainer> trainersList = new ArrayList<PersonalTrainer>();
        for (Employee e : employees) {
            if (e instanceof PersonalTrainer) {
                trainersList.add((PersonalTrainer) e);
            }
        }
        return trainersList;
    }

    public ArrayList<Member> getMembersAssignedToTrainer(int trainerId) {
        Employee e = findEmployeeById(trainerId);
        if (e instanceof PersonalTrainer) {
            return new ArrayList<Member>(((PersonalTrainer) e).getMembers());
        }
        return new ArrayList<Member>();
    }

    // --- Interface Method Implementations (Reportable) ---
    @Override
    public boolean canDeleteTrainer(int trainerId) {
        Employee e = findEmployeeById(trainerId);
        if (e instanceof PersonalTrainer) {
            return ((PersonalTrainer) e).getMemberCount() == 0;
        }
        return true; 
    }

    @Override
    public void generateMarketingReport() {
        PrintWriter writer = null;
        try {
            LocalDateTime generatedAt = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

            writer = new PrintWriter(new FileWriter("marketingReport.txt"));
            writer.println("=================================================");
            writer.println("   POLYFIT GYM MANAGEMENT SYSTEM - MARKETING REPORT");
            writer.println("=================================================");
            writer.println();
            writer.println("Generated on: " + generatedAt.format(formatter));
            writer.println();
            
            writer.println("--- POLYTECHNIC STAFF MEMBERS ---");
            int staffCount = 0;
            for (Member m : members) {
                if (m instanceof PolyStaff) {
                    PolyStaff ps = (PolyStaff) m;
                    writer.printf("ID: %-5d Name: %-20s Dept: %-15s Position: %s%n", 
                        ps.getMemberId(), (ps.getFirstName() + " " + ps.getLastName()), 
                        ps.getDepartment(), ps.getPosition());
                    staffCount++;
                }
            }
            writer.println("Total Staff Members: " + staffCount);
            writer.println();

            writer.println("--- POLYTECHNIC STUDENT MEMBERS ---");
            int studentCount = 0;
            for (Member m : members) {
                if (m instanceof PolyStudent) {
                    PolyStudent ps = (PolyStudent) m;
                    writer.printf("ID: %-5d Name: %-20s Course: %-15s Team: %s%n", 
                        ps.getMemberId(), (ps.getFirstName() + " " + ps.getLastName()), 
                        ps.getCourse(), ps.getTeam().isEmpty() ? "None" : ps.getTeam());
                    studentCount++;
                }
            }
            writer.println("Total Student Members: " + studentCount);
            writer.println();
            writer.println("=================================================");
            writer.println("End of Report.");
        } catch (IOException ex) {
            System.err.println("Error generating text based report structure: " + ex.getMessage());
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }
}