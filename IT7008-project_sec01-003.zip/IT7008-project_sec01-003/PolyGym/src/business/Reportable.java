package business;

/**
 *
 * @author Tasbeeh
 */
public interface Reportable {
    void generateMarketingReport();
    boolean canDeleteTrainer(int trainerId);
}