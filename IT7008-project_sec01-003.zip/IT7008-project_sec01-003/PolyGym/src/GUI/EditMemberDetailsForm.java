package GUI;

import business.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Form for updating or removing existing Gym Members.
 * UPDATED: Uses a JComboBox displaying "ID - Full Name" for easy picking.
 * @author Ali ALmawlani
 */
public class EditMemberDetailsForm extends javax.swing.JFrame {
    private static final long serialVersionUID = 1L;

    private GymSystem gym;
    private MainMenu mainMenu;
    private Member activeMember = null;

    private JComboBox<String> searchIdCombo;
    private JTextField fNameTxt, lNameTxt, dobTxt, addressTxt, phoneTxt, ex1Txt, ex2Txt;
    private JLabel ex1Label, ex2Label, classificationLbl;
    private JButton searchBtn, saveBtn, backBtn;

    public EditMemberDetailsForm(GymSystem gym, MainMenu mainMenu) {
        this.gym = gym;
        this.mainMenu = mainMenu;
        initComponents();
        populateIdComboBox();
        this.setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("PolyFit System - Edit Member Profile");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setSize(700, 650);

        JPanel mainPanel = new JPanel(new BorderLayout(12, 15));
        mainPanel.setBorder(new EmptyBorder(20, 25, 20, 25));
        mainPanel.setBackground(new Color(245, 247, 250));

        // --- Search Bar Header ---
        JPanel searchBar = new JPanel(new BorderLayout(10, 0));
        searchBar.setBackground(Color.WHITE);
        searchBar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1), new EmptyBorder(8, 10, 8, 10)
        ));

        searchIdCombo = new JComboBox<>();
        
        searchBtn = new JButton("Fetch Profile");
        searchBtn.setBorderPainted(false);
        searchBtn.setOpaque(true);
        searchBtn.setContentAreaFilled(true);
        searchBtn.setBackground(new Color(63, 81, 181));
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFocusPainted(false);
        
        searchBar.add(new JLabel("Select Member: "), BorderLayout.WEST);
        searchBar.add(searchIdCombo, BorderLayout.CENTER);
        searchBar.add(searchBtn, BorderLayout.EAST);
        mainPanel.add(searchBar, BorderLayout.NORTH);

        // --- Edit Form Inputs ---
        JPanel formGrid = new JPanel(new GridLayout(8, 2, 10, 12));
        formGrid.setOpaque(false);
        Font lblFont = new Font("Segoe UI", Font.BOLD, 13);

        JLabel accountCategoryLabel = new JLabel("Account Category:");
        accountCategoryLabel.setFont(lblFont);
        formGrid.add(accountCategoryLabel);
        classificationLbl = new JLabel("[No Member Loaded]");
        classificationLbl.setFont(new Font("Segoe UI", Font.ITALIC | Font.BOLD, 13));
        formGrid.add(classificationLbl);

        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setFont(lblFont);
        formGrid.add(firstNameLabel); fNameTxt = new JTextField(); formGrid.add(fNameTxt);
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setFont(lblFont);
        formGrid.add(lastNameLabel); lNameTxt = new JTextField(); formGrid.add(lNameTxt);
        JLabel dobLabel = new JLabel("Date of Birth:");
        dobLabel.setFont(lblFont);
        formGrid.add(dobLabel); dobTxt = new JTextField(); formGrid.add(dobTxt);
        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setFont(lblFont);
        formGrid.add(addressLabel); addressTxt = new JTextField(); formGrid.add(addressTxt);
        JLabel phoneLabel = new JLabel("Phone Number:");
        phoneLabel.setFont(lblFont);
        formGrid.add(phoneLabel); phoneTxt = new JTextField(); formGrid.add(phoneTxt);

        ex1Label = new JLabel("Course / Position:");
        ex1Label.setFont(lblFont);
        ex1Txt = new JTextField();
        formGrid.add(ex1Label); formGrid.add(ex1Txt);
        ex2Label = new JLabel("Team / Department:");
        ex2Label.setFont(lblFont);
        ex2Txt = new JTextField();
        formGrid.add(ex2Label); formGrid.add(ex2Txt);

        mainPanel.add(formGrid, BorderLayout.CENTER);

        // --- Action Row Footer Buttons ---
        JPanel bottomBar = new JPanel(new GridLayout(1, 2, 10, 0));
        saveBtn = new JButton("Save Changes"); backBtn = new JButton("Back");
        
        JButton[] buttonsList = {saveBtn, backBtn};
        for (JButton btn : buttonsList) {
            btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
            btn.setFocusPainted(false);
            btn.setPreferredSize(new Dimension(0, 40));
            btn.setBorderPainted(false);
            btn.setOpaque(true);
            btn.setContentAreaFilled(true);
        }
        
        saveBtn.setBackground(new Color(46, 125, 50)); saveBtn.setForeground(Color.WHITE);
        backBtn.setBackground(new Color(117, 117, 117)); backBtn.setForeground(Color.WHITE);

        bottomBar.add(saveBtn); bottomBar.add(backBtn);
        mainPanel.add(bottomBar, BorderLayout.SOUTH);

        toggleFields(false);

        add(mainPanel);

        searchBtn.addActionListener(e -> performSearch());
        saveBtn.addActionListener(e -> performUpdates());
        backBtn.addActionListener(e -> {
            mainMenu.refreshStatisticsSummary();
            mainMenu.setVisible(true);
            this.dispose();
        });
    }

    private void populateIdComboBox() {
        searchIdCombo.removeAllItems();
        for (Member m : gym.getMembers()) {
            searchIdCombo.addItem(m.getMemberId() + " - " + m.getFirstName() + " " + m.getLastName());
        }
    }

    private void toggleFields(boolean state) {
        fNameTxt.setEnabled(state); lNameTxt.setEnabled(state); dobTxt.setEnabled(state);
        addressTxt.setEnabled(state); phoneTxt.setEnabled(state); ex1Txt.setEnabled(state);
        ex2Txt.setEnabled(state); saveBtn.setEnabled(state);
    }

    private void performSearch() {
        String selectedString = (String) searchIdCombo.getSelectedItem();
        if (selectedString == null) {
            classificationLbl.setText("[No Member Loaded]");
            toggleFields(false);
            JOptionPane.showMessageDialog(this, "No members are logged in the system registry.");
            return;
        }

        int id = Integer.parseInt(selectedString.split(" - ")[0]);
        Member m = gym.findMemberById(id);
        if (m == null) {
            toggleFields(false);
            classificationLbl.setText("[No Member Loaded]");
            return;
        }

        activeMember = m;
        fNameTxt.setText(m.getFirstName());
        lNameTxt.setText(m.getLastName());
        dobTxt.setText(m.getDateOfBirth());
        addressTxt.setText(m.getAddress());
        phoneTxt.setText(m.getPhone());

        if (m instanceof PolyStudent) {
            classificationLbl.setText("POLYTENCHNIC STUDENT");
            ex1Label.setText("Modify Course:"); ex2Label.setText("Modify Sports Team:");
            ex1Txt.setText(((PolyStudent) m).getCourse());
            ex2Txt.setText(((PolyStudent) m).getTeam());
        } else {
            classificationLbl.setText("POLYTECHNIC STAFF");
            ex1Label.setText("Modify Job Position:"); ex2Label.setText("Modify Department:");
            ex1Txt.setText(((PolyStaff) m).getPosition());
            ex2Txt.setText(((PolyStaff) m).getDepartment());
        }
        toggleFields(true);
    }

    private void performUpdates() {
        if (activeMember == null) return;
        try {
            String fName = fNameTxt.getText().trim();
            String lName = lNameTxt.getText().trim();
            String dob = dobTxt.getText().trim();
            String address = addressTxt.getText().trim();
            String phone = phoneTxt.getText().trim();

            GymSystem.validateName(fName, "First name");
            GymSystem.validateName(lName, "Last name");
            GymSystem.validateDateOfBirth(dob);
            GymSystem.validateAddress(address);
            GymSystem.validatePhoneNumber(phone);

            activeMember.setFirstName(fName);
            activeMember.setLastName(lName);
            activeMember.setDateOfBirth(dob);
            activeMember.setAddress(address);
            activeMember.setPhone(phone);

            if (activeMember instanceof PolyStudent) {
                String course = ex1Txt.getText().trim();
                String team = ex2Txt.getText().trim();
                GymSystem.validateDescription(course, "Course");
                GymSystem.validateDescription(team.isEmpty() ? "Team" : team, "Sports team");
                ((PolyStudent) activeMember).setCourse(course);
                ((PolyStudent) activeMember).setTeam(team);
            } else {
                String position = ex1Txt.getText().trim();
                String department = ex2Txt.getText().trim();
                GymSystem.validateDescription(position, "Position");
                GymSystem.validateDescription(department, "Department");
                ((PolyStaff) activeMember).setPosition(position);
                ((PolyStaff) activeMember).setDepartment(department);
            }
            JOptionPane.showMessageDialog(this, "Member configurations saved.");
            populateIdComboBox(); // Refresh labels inside dropdown string layout
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error processing changes: " + ex.getMessage());
        }
    }

}