package business;

/**
 *
 * @author Tasbeeh
 */
import java.io.*;

/**
 * System startup file-populating data utility.
 * FIXED: Properly parses primitive numeric inputs and calls the explicit subclass methods.
 * @author huzaifasuhail
 */
public class StartupLoader {
    private static final String STARTUP_FILE = "startup.txt";

    public static void loadFromFile(GymSystem system) {
        File file = new File(STARTUP_FILE);
        if (!file.exists()) {
            System.out.println("Startup config text file missing. Initialising built-in demo data.");
            seedBuiltInDemoData(system);
            return;
        }

        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String firstLine = nextNonBlankLine(reader);
            if (firstLine != null) {
                try {
                    int employeeCount = Integer.parseInt(firstLine.trim());
                    loadStructuredStartup(system, reader, employeeCount);
                    System.out.println("Startup configuration successfully processed into registry context.");
                    return;
                } catch (NumberFormatException ignored) {
                    // Fall back to legacy CSV-style format below.
                }
            }

            // Legacy fallback for older startup.txt content.
            reader.close();
            reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;

                String[] tokens = line.split(",");
                for (int i = 0; i < tokens.length; i++) {
                    tokens[i] = tokens[i].trim();
                }

                String type = tokens[0].toUpperCase();
                if (type.equals("EMPLOYEE") || type.equals("TRAINER")) {
                    double salary = Double.parseDouble(tokens[1]);
                    String fName = tokens[2];
                    String lName = tokens[3];
                    String addr = tokens[4];
                    String phone = tokens[5];
                    int id = system.getNextStaffId();
                    boolean isTrainer = type.equals("TRAINER");
                    system.addEmployee(id, fName, lName, addr, phone, salary, isTrainer);
                } else if (type.equals("STAFF") || type.equals("STUDENT")) {
                    String dob = tokens[1];
                    String gender = tokens[2];
                    String fName = tokens[3];
                    String lName = tokens[4];
                    String addr = tokens[5];
                    String phone = tokens[6];
                    String extra1 = tokens[7];
                    String extra2 = tokens.length > 8 ? tokens[8] : "";
                    int memberId = system.getNextMemberId();
                    if (type.equals("STAFF")) {
                        system.addPolyStaff(memberId, dob, gender, extra1, extra2, fName, lName, addr, phone);
                    } else {
                        system.addPolyStudent(memberId, dob, gender, extra1, extra2, fName, lName, addr, phone);
                    }
                }
            }
            System.out.println("Legacy startup configuration processed.");
        } catch (Exception e) {
            System.err.println("Error reading startup configuration initialization parsing values: " + e.getMessage());
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    private static String nextNonBlankLine(BufferedReader reader) throws IOException {
        String line;
        while ((line = reader.readLine()) != null) {
            String trimmed = line.trim();
            if (!trimmed.isEmpty() && !trimmed.startsWith("#")) {
                return trimmed;
            }
        }
        return null;
    }

    private static void loadStructuredStartup(GymSystem system, BufferedReader reader, int employeeCount) throws IOException {
        for (int i = 0; i < employeeCount; i++) {
            String typeLine = nextNonBlankLine(reader);
            if (typeLine == null) {
                throw new IOException("Incomplete startup file: missing employee record.");
            }

            boolean isTrainer = typeLine.equalsIgnoreCase("PT") || typeLine.equalsIgnoreCase("TRAINER");
            String firstName = nextNonBlankLine(reader);
            String lastName = nextNonBlankLine(reader);
            String address = nextNonBlankLine(reader);
            String phone = nextNonBlankLine(reader);
            String salaryText = nextNonBlankLine(reader);
            double salary = Double.parseDouble(salaryText.trim());

            Employee employee = system.addEmployee(system.getNextStaffId(), firstName, lastName, address, phone, salary, isTrainer);

            if (isTrainer) {
                String memberCountText = nextNonBlankLine(reader);
                int memberCount = Integer.parseInt(memberCountText.trim());
                for (int j = 0; j < memberCount; j++) {
                    String memberType = nextNonBlankLine(reader);
                    String memberFirst = nextNonBlankLine(reader);
                    String memberLast = nextNonBlankLine(reader);
                    String memberAddress = nextNonBlankLine(reader);
                    String dob = nextNonBlankLine(reader);
                    String memberPhone = nextNonBlankLine(reader);
                    String gender = nextNonBlankLine(reader);
                    String extra1 = nextNonBlankLine(reader);
                    String extra2 = nextNonBlankLine(reader);

                    int memberId = system.getNextMemberId();
                    Member member;
                    if (memberType.equalsIgnoreCase("staff")) {
                        member = system.addPolyStaff(memberId, dob, gender, extra1, extra2, memberFirst, memberLast, memberAddress, memberPhone);
                    } else {
                        member = system.addPolyStudent(memberId, dob, gender, extra1, extra2, memberFirst, memberLast, memberAddress, memberPhone);
                    }
                    system.assignTrainer(member.getMemberId(), employee.getStaffId());
                }
            }
        }
    }

    private static void seedBuiltInDemoData(GymSystem system) {
        if (!system.getEmployees().isEmpty() || !system.getMembers().isEmpty()) {
            return;
        }

        PersonalTrainer coach = (PersonalTrainer) system.addEmployee(system.getNextStaffId(), "Alex", "Morgan", "1 Gym Street", "555-0101", 4200.0, true);
        system.addEmployee(system.getNextStaffId(), "Jordan", "Lee", "2 Fitness Avenue", "555-0102", 3800.0, false);

        Member student = system.addPolyStudent(system.getNextMemberId(), "2003-05-12", "Female", "Software", "Team Alpha", "Mia", "Nguyen", "10 Campus Road", "555-0201");
        Member staff = system.addPolyStaff(system.getNextMemberId(), "1988-02-18", "Male", "Senior Trainer", "Wellness", "Noah", "Patel", "20 Staff Lane", "555-0202");

        system.assignTrainer(student.getMemberId(), coach.getStaffId());
        system.assignTrainer(staff.getMemberId(), coach.getStaffId());
    }
}