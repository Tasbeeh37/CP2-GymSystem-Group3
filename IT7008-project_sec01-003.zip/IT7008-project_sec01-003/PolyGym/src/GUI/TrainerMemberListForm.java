package GUI;

import business.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Displays all members currently assigned to a chosen personal trainer.
 * @author Ali Jawad 
 */
public class TrainerMemberListForm extends JFrame {
    private static final long serialVersionUID = 1L;

    private final GymSystem gym;
    private final MainMenu mainMenu;
    private JComboBox<String> trainerCombo;
    private JTextArea membersArea;

    public TrainerMemberListForm(GymSystem gym, MainMenu mainMenu) {
        this.gym = gym;
        this.mainMenu = mainMenu;
        initComponents();
        populateTrainers();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("PolyFit System - Trainer Member List");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(720, 520);

        JPanel panel = new JPanel(new BorderLayout(10, 15));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(245, 247, 250));

        JLabel header = new JLabel("LIST MEMBERS BY TRAINER", SwingConstants.CENTER);
        header.setFont(new Font("Segoe UI", Font.BOLD, 16));
        header.setForeground(new Color(63, 81, 181));
        panel.add(header, BorderLayout.NORTH);

        JPanel topPanel = new JPanel(new BorderLayout(10, 0));
        topPanel.setOpaque(false);
        topPanel.add(new JLabel("Select Personal Trainer:"), BorderLayout.WEST);
        trainerCombo = new JComboBox<>();
        topPanel.add(trainerCombo, BorderLayout.CENTER);

        JButton showBtn = new JButton("Show Members");
        showBtn.setBackground(new Color(63, 81, 181));
        showBtn.setForeground(Color.WHITE);
        showBtn.setFocusPainted(false);
        showBtn.setBorderPainted(false);
        showBtn.setOpaque(true);
        showBtn.setContentAreaFilled(true);
        topPanel.add(showBtn, BorderLayout.EAST);

        panel.add(topPanel, BorderLayout.NORTH);

        membersArea = new JTextArea();
        membersArea.setEditable(false);
        membersArea.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        membersArea.setLineWrap(true);
        membersArea.setWrapStyleWord(true);
        membersArea.setText("Choose a trainer and click \"Show Members\" to view the assigned members.");

        JScrollPane scrollPane = new JScrollPane(membersArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210)));
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setOpaque(false);
        JButton backBtn = new JButton("Back to Main Menu");
        backBtn.setBackground(new Color(117, 117, 117));
        backBtn.setForeground(Color.WHITE);
        backBtn.setFocusPainted(false);
        backBtn.setBorderPainted(false);
        backBtn.setOpaque(true);
        backBtn.setContentAreaFilled(true);
        bottomPanel.add(backBtn);
        panel.add(bottomPanel, BorderLayout.SOUTH);

        add(panel);

        showBtn.addActionListener(e -> showMembers());
        backBtn.addActionListener(e -> {
            mainMenu.refreshStatisticsSummary();
            mainMenu.setVisible(true);
            dispose();
        });
    }

    private void populateTrainers() {
        trainerCombo.removeAllItems();
        for (PersonalTrainer trainer : gym.getTrainers()) {
            trainerCombo.addItem(trainer.getStaffId() + " - " + trainer.getFirstName() + " " + trainer.getLastName());
        }
    }

    private void showMembers() {
        if (trainerCombo.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please choose a personal trainer.");
            return;
        }

        int trainerId = Integer.parseInt(trainerCombo.getSelectedItem().toString().split(" - ")[0]);
        membersArea.setText(TrainerMemberReport.buildList(gym, trainerId));
    }
}
