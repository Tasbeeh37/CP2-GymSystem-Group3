package GUI;

import business.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Dedicated page for deleting an employee record from the system.
 * @author Ali Almawlani
 */

//DeleteEmployeeForm
public class DeleteEmployeeForm extends JFrame {
    private static final long serialVersionUID = 1L;

    private final GymSystem gym;
    private final MainMenu mainMenu;
    private JComboBox<String> employeeCombo;
    private JButton deleteBtn;

    public DeleteEmployeeForm(GymSystem gym, MainMenu mainMenu) {
        this.gym = gym;
        this.mainMenu = mainMenu;
        initComponents();
        populateEmployeeCombo();
        this.setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("PolyFit System - Delete Employee");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(700, 400);

        JPanel outerPanel = new JPanel(new BorderLayout(15, 15));
        outerPanel.setBorder(new EmptyBorder(20, 25, 20, 25));
        outerPanel.setBackground(new Color(245, 247, 250));

        JLabel header = new JLabel("REMOVE EMPLOYEE RECORD", SwingConstants.CENTER);
        header.setFont(new Font("Segoe UI", Font.BOLD, 18));
        header.setForeground(new Color(63, 81, 181));
        outerPanel.add(header, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setOpaque(false);

        JPanel selectorRow = new JPanel(new BorderLayout(10, 0));
        selectorRow.setOpaque(false);
        selectorRow.add(new JLabel("Select Employee to Delete:"), BorderLayout.WEST);

        employeeCombo = new JComboBox<>();
        employeeCombo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        selectorRow.add(employeeCombo, BorderLayout.CENTER);
        centerPanel.add(selectorRow, BorderLayout.NORTH);

        JTextArea helpArea = new JTextArea("Choose an employee from the list, then click Delete to remove the profile from the system. This operation cannot be undone.");
        helpArea.setLineWrap(true);
        helpArea.setWrapStyleWord(true);
        helpArea.setEditable(false);
        helpArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        helpArea.setBackground(new Color(245, 247, 250));
        helpArea.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        centerPanel.add(helpArea, BorderLayout.CENTER);

        outerPanel.add(centerPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        buttonPanel.setOpaque(false);

        deleteBtn = new JButton("Delete Employee");
        deleteBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.setBackground(new Color(198, 40, 40));
        deleteBtn.setFocusPainted(false);
        deleteBtn.setBorderPainted(false);
        deleteBtn.setOpaque(true);
        deleteBtn.setContentAreaFilled(true);

        JButton backBtn = new JButton("Back to Main Menu");
        backBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        backBtn.setForeground(Color.WHITE);
        backBtn.setBackground(new Color(117, 117, 117));
        backBtn.setFocusPainted(false);
        backBtn.setBorderPainted(false);
        backBtn.setOpaque(true);
        backBtn.setContentAreaFilled(true);

        buttonPanel.add(deleteBtn);
        buttonPanel.add(backBtn);
        outerPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(outerPanel);

        deleteBtn.addActionListener(e -> performDelete());
        backBtn.addActionListener(e -> {
            mainMenu.refreshStatisticsSummary();
            mainMenu.setVisible(true);
            dispose();
        });
    }

    private void populateEmployeeCombo() {
        employeeCombo.removeAllItems();
        for (Employee emp : gym.getEmployees()) {
            employeeCombo.addItem(emp.getStaffId() + " - " + emp.getFirstName() + " " + emp.getLastName());
        }
        deleteBtn.setEnabled(employeeCombo.getItemCount() > 0);
    }

    private void performDelete() {
        String selected = (String) employeeCombo.getSelectedItem();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "No employee selected.", "Delete Employee", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int id = Integer.parseInt(selected.split(" - ")[0]);
        int choice = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete employee record " + id + "?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (choice == JOptionPane.YES_OPTION) {
            gym.deleteEmployee(id);
            JOptionPane.showMessageDialog(this, "Employee record deleted successfully.", "Deleted", JOptionPane.INFORMATION_MESSAGE);
            populateEmployeeCombo();
            mainMenu.refreshStatisticsSummary();
        }
    }
}
