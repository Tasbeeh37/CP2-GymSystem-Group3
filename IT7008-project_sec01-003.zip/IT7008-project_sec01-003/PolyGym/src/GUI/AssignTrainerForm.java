package GUI;

/**
 * Window for assigning or removing trainer links to members.
 * It lets the user connect a member with a trainer and review the resulting relationship.
 * @version 1.0
 */


import business.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;

/**
 * Interface coordinating Personal Trainer assignment connections.
 * UPDATED: Replaced all text entry panels with "ID - Full Name" ComboBox fields.
 * @author Ali Jawad
 */

//AssignTrainerForm
public class AssignTrainerForm extends javax.swing.JFrame {
    private static final long serialVersionUID = 1L;

    private GymSystem gym;
    private MainMenu mainMenu;

    private JComboBox<String> memberCombo;
    private JComboBox<String> trainerCombo;
    private JLabel relationshipStatusLbl;
    private JButton checkStatusBtn, assignBtn, removeBtn, viewMembersBtn, backBtn;

    public AssignTrainerForm(GymSystem gym, MainMenu mainMenu) {
        this.gym = gym;
        this.mainMenu = mainMenu;
        initComponents();
        populateDropDownMenus();
        this.setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("PolyFit System - Coach Assignments Panel");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setSize(680, 520);

        JPanel panel = new JPanel(new BorderLayout(10, 15));
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));
        panel.setBackground(new Color(245, 247, 250));

        // Header Title
        JLabel header = new JLabel("MANAGE PERSONAL TRAINER ASSIGNMENTS", SwingConstants.CENTER);
        header.setFont(new Font("Segoe UI", Font.BOLD, 16));
        header.setForeground(new Color(63, 81, 181));
        panel.add(header, BorderLayout.NORTH);

        JPanel centerGrid = new JPanel(new GridLayout(4, 1, 10, 12));
        centerGrid.setOpaque(false);

        // Member Selection Row
        JPanel row1 = new JPanel(new BorderLayout(10, 0));
        row1.setOpaque(false);
        row1.add(new JLabel("Select Member:"), BorderLayout.WEST);
        memberCombo = new JComboBox<>();
        memberCombo.setPreferredSize(new Dimension(Short.MAX_VALUE, 40));
        memberCombo.setMinimumSize(new Dimension(120, 40));
        memberCombo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        checkStatusBtn = new JButton("Check Assignment");
        checkStatusBtn.setBorderPainted(false);
        checkStatusBtn.setOpaque(true);
        checkStatusBtn.setContentAreaFilled(true);
        checkStatusBtn.setBackground(new Color(63, 81, 181));
        checkStatusBtn.setForeground(Color.WHITE);
        checkStatusBtn.setFocusPainted(false);
        checkStatusBtn.setPreferredSize(new Dimension(180, 40));
        checkStatusBtn.setMinimumSize(new Dimension(180, 40));
        checkStatusBtn.setMaximumSize(new Dimension(180, 40));
        checkStatusBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));

        JPanel memberRowControls = new JPanel();
        memberRowControls.setLayout(new BoxLayout(memberRowControls, BoxLayout.X_AXIS));
        memberRowControls.setOpaque(false);
        memberRowControls.add(memberCombo);
        memberRowControls.add(Box.createRigidArea(new Dimension(12, 0)));
        memberRowControls.add(checkStatusBtn);

        row1.add(memberRowControls, BorderLayout.CENTER);

        // Trainer Selection Row
        JPanel row2 = new JPanel(new BorderLayout(10, 0)); row2.setOpaque(false);
        row2.add(new JLabel("Select Personal Trainer:"), BorderLayout.WEST);
        trainerCombo = new JComboBox<>();
        row2.add(trainerCombo, BorderLayout.CENTER);

        // Feedback Label Row
        JPanel row3 = new JPanel(new BorderLayout()); row3.setOpaque(false);
        relationshipStatusLbl = new JLabel("Choose a Member above to check coaching profiles.", SwingConstants.CENTER);
        relationshipStatusLbl.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        relationshipStatusLbl.setForeground(Color.DARK_GRAY);
        row3.add(relationshipStatusLbl);

        centerGrid.add(row1);
        centerGrid.add(row2);
        centerGrid.add(row3);
        panel.add(centerGrid, BorderLayout.CENTER);

        // --- Action Buttons Layout ---
        JPanel buttonRow = new JPanel(new GridLayout(1, 4, 8, 0));
        assignBtn = new JButton("Link Assignment");
        removeBtn = new JButton("Remove Link");
        viewMembersBtn = new JButton("List Trainer Members");
        backBtn = new JButton("Back");

        JButton[] assignmentRow = {assignBtn, removeBtn, viewMembersBtn, backBtn};
        for (JButton button : assignmentRow) {
            button.setFont(new Font("Segoe UI", Font.BOLD, 13));
            button.setFocusPainted(false);
            button.setPreferredSize(new Dimension(0, 40));
            button.setBorderPainted(false);
            button.setOpaque(true);
            button.setContentAreaFilled(true);
        }

        assignBtn.setBackground(new Color(46, 125, 50)); assignBtn.setForeground(Color.WHITE);
        removeBtn.setBackground(new Color(230, 81, 0)); removeBtn.setForeground(Color.WHITE);
        viewMembersBtn.setBackground(new Color(0, 121, 107)); viewMembersBtn.setForeground(Color.WHITE);
        backBtn.setBackground(new Color(117, 117, 117)); backBtn.setForeground(Color.WHITE);

        buttonRow.add(assignBtn); buttonRow.add(removeBtn); buttonRow.add(viewMembersBtn); buttonRow.add(backBtn);
        panel.add(buttonRow, BorderLayout.SOUTH);

        add(panel);

        checkStatusBtn.addActionListener(e -> checkStatus());
        assignBtn.addActionListener(e -> processLink(true));
        removeBtn.addActionListener(e -> processLink(false));
        viewMembersBtn.addActionListener(e -> showAssignedMembers());
        backBtn.addActionListener(e -> {
            mainMenu.refreshStatisticsSummary();
            mainMenu.setVisible(true);
            this.dispose();
        });
    }
//populateDropDownMenus
    private void populateDropDownMenus() {
        memberCombo.removeAllItems();
        for (Member m : gym.getMembers()) {
            memberCombo.addItem(m.getMemberId() + " - " + m.getFirstName() + " " + m.getLastName());
        }

        trainerCombo.removeAllItems();
        for (PersonalTrainer pt : gym.getTrainers()) {
            trainerCombo.addItem(pt.getStaffId() + " - " + pt.getFirstName() + " " + pt.getLastName());
        }
    }
//checkStatus
    private void checkStatus() {
        String memberSelection = (String) memberCombo.getSelectedItem();
        if (memberSelection == null) {
            relationshipStatusLbl.setText("No registered members available.");
            return;
        }

        int mId = Integer.parseInt(memberSelection.split(" - ")[0]);
        Member m = gym.findMemberById(mId);
        if (m == null) return;

        if (m.getTrainer() == null) {
            relationshipStatusLbl.setText(m.getFirstName() + " " + m.getLastName() + " -> [No Trainer Assigned]");
        } else {
            PersonalTrainer pt = m.getTrainer();
            relationshipStatusLbl.setText("Member: " + m.getFirstName() + " -> Trainer: " + pt.getFirstName() + " " + pt.getLastName());
        }
    }
//showAssignedMembers
    private void showAssignedMembers() {
        String trainerSelection = (String) trainerCombo.getSelectedItem();
        if (trainerSelection == null) {
            JOptionPane.showMessageDialog(this, "Please select a personal trainer first.");
            return;
        }

        int trainerId = Integer.parseInt(trainerSelection.split(" - ")[0]);
        ArrayList<Member> assignedMembers = gym.getMembersAssignedToTrainer(trainerId);

        if (assignedMembers.isEmpty()) {
            JOptionPane.showMessageDialog(this, "This trainer currently has no assigned members.", "No Members", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder message = new StringBuilder("Members currently assigned to trainer " + trainerSelection + ":\n");
        for (Member member : assignedMembers) {
            message.append("• ").append(member.getMemberId()).append(" - ")
                   .append(member.getFirstName()).append(' ').append(member.getLastName()).append("\n");
        }

        JOptionPane.showMessageDialog(this, message.toString(), "Assigned Members", JOptionPane.INFORMATION_MESSAGE);
    }

    private void processLink(boolean linkAction) {
        String memberSelection = (String) memberCombo.getSelectedItem();
        if (memberSelection == null) {
            JOptionPane.showMessageDialog(this, "Please verify a target member is selected.");
            return;
        }

        int mId = Integer.parseInt(memberSelection.split(" - ")[0]);

        try {
            if (!linkAction) {
                gym.removeTrainer(mId);
                JOptionPane.showMessageDialog(this, "Coaching assignment severed cleanly.");
                checkStatus();
                return;
            }

            String trainerSelection = (String) trainerCombo.getSelectedItem();
            if (trainerSelection == null) {
                throw new IllegalArgumentException("No personal trainers are currently active in the system registry.");
            }

            int tId = Integer.parseInt(trainerSelection.split(" - ")[0]);
            gym.assignTrainer(mId, tId);
            JOptionPane.showMessageDialog(this, "Trainer assignment linked successfully!");
            checkStatus();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Assignment Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}