package GUI;

import business.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Administrative Form managing entity verification updates and record purge commands.
 * UPDATED: Uses a JComboBox displaying "ID - Full Name" for easier selection.
 * @author huzaifasuhail
 */
public class EditEmployeeDetailsForm extends javax.swing.JFrame {
    private static final long serialVersionUID = 1L;

    private GymSystem gym;
    private MainMenu mainMenu;
    private Employee activeTarget = null;

    // Interface Form Elements
    private JComboBox<String> searchIdCombo;
    private JTextField fNameTxt;
    private JTextField lNameTxt;
    private JTextField addressTxt;
    private JTextField phoneTxt;
    private JTextField salaryTxt;
    private JLabel typeStatusLbl;
    private JButton searchBtn;
    private JButton saveBtn;
    private JButton backBtn;

    public EditEmployeeDetailsForm(GymSystem gym, MainMenu mainMenu) {
        this.gym = gym;
        this.mainMenu = mainMenu;
        initComponents();
        populateIdComboBox(); 
        this.setLocationRelativeTo(null);
    }

    private void initComponents() {
        setTitle("PolyFit Administration System - Edit Employee Records");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setSize(700, 640);

        JPanel outerPanel = new JPanel(new BorderLayout(12, 15));
        outerPanel.setBorder(new EmptyBorder(20, 25, 20, 25));
        outerPanel.setBackground(new Color(245, 247, 250));

        // --- Top Row Entry Lookup Control Region ---
        JPanel searchContainer = new JPanel(new BorderLayout(10, 0));
        searchContainer.setBackground(Color.WHITE);
        searchContainer.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            new EmptyBorder(10, 12, 10, 12)
        ));

        JLabel searchPrompt = new JLabel("Select Employee:");
        searchPrompt.setFont(new Font("Segoe UI", Font.BOLD, 13));
        
        searchIdCombo = new JComboBox<>();
        
        searchBtn = new JButton("Fetch Profile");
        searchBtn.setBorderPainted(false);
        searchBtn.setOpaque(true);
        searchBtn.setContentAreaFilled(true);
        searchBtn.setBackground(new Color(63, 81, 181));
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFocusPainted(false);

        searchContainer.add(searchPrompt, BorderLayout.WEST);
        searchContainer.add(searchIdCombo, BorderLayout.CENTER);
        searchContainer.add(searchBtn, BorderLayout.EAST);
        outerPanel.add(searchContainer, BorderLayout.NORTH);

        // --- Core Context Data Registry Updates Grid ---
        JPanel fieldsGrid = new JPanel(new GridLayout(6, 2, 10, 15));
        fieldsGrid.setOpaque(false);
        Font lblFont = new Font("Segoe UI", Font.BOLD, 13);

        JLabel classificationLabel = new JLabel("Classification System Type:");
        classificationLabel.setFont(lblFont);
        fieldsGrid.add(classificationLabel);
        typeStatusLbl = new JLabel("[No Profile Context Loaded]");
        typeStatusLbl.setFont(new Font("Segoe UI", Font.ITALIC | Font.BOLD, 13));
        typeStatusLbl.setForeground(Color.GRAY);
        fieldsGrid.add(typeStatusLbl);

        JLabel firstNameLabel = new JLabel("Modify First Name:");
        firstNameLabel.setFont(lblFont);
        fieldsGrid.add(firstNameLabel);
        fNameTxt = new JTextField();
        fNameTxt.setPreferredSize(new Dimension(0, 32));
        fieldsGrid.add(fNameTxt);

        JLabel lastNameLabel = new JLabel("Modify Last Name:");
        lastNameLabel.setFont(lblFont);
        fieldsGrid.add(lastNameLabel);
        lNameTxt = new JTextField();
        lNameTxt.setPreferredSize(new Dimension(0, 32));
        fieldsGrid.add(lNameTxt);

        JLabel addressLabel = new JLabel("Modify Home Address:");
        addressLabel.setFont(lblFont);
        fieldsGrid.add(addressLabel);
        addressTxt = new JTextField();
        addressTxt.setPreferredSize(new Dimension(0, 32));
        fieldsGrid.add(addressTxt);

        JLabel phoneLabel = new JLabel("Modify Phone Line:");
        phoneLabel.setFont(lblFont);
        fieldsGrid.add(phoneLabel);
        phoneTxt = new JTextField();
        phoneTxt.setPreferredSize(new Dimension(0, 32));
        fieldsGrid.add(phoneTxt);

        JLabel salaryLabel = new JLabel("Modify Salary Rates ($):");
        salaryLabel.setFont(lblFont);
        fieldsGrid.add(salaryLabel);
        salaryTxt = new JTextField();
        salaryTxt.setPreferredSize(new Dimension(0, 32));
        fieldsGrid.add(salaryTxt);

        outerPanel.add(fieldsGrid, BorderLayout.CENTER);

        // --- Bottom Actions Control Rows Menu ---
        JPanel bottomBar = new JPanel(new GridLayout(1, 2, 10, 0));
        bottomBar.setOpaque(false);

        saveBtn = new JButton("Commit Changes");
        backBtn = new JButton("Back to Dashboard");

        JButton[] operationalRow = {saveBtn, backBtn};
        for (JButton button : operationalRow) {
            button.setFont(new Font("Segoe UI", Font.BOLD, 13));
            button.setFocusPainted(false);
            button.setPreferredSize(new Dimension(0, 40));
            button.setBorderPainted(false);
            button.setOpaque(true);
            button.setContentAreaFilled(true);
        }

        saveBtn.setBackground(new Color(46, 125, 50));
        saveBtn.setForeground(Color.WHITE);
        backBtn.setBackground(new Color(117, 117, 117));
        backBtn.setForeground(Color.WHITE);

        bottomBar.add(saveBtn);
        bottomBar.add(backBtn);
        outerPanel.add(bottomBar, BorderLayout.SOUTH);

        add(outerPanel);

        toggleInputState(false);

        searchBtn.addActionListener(evt -> executeProfileLookup());
        saveBtn.addActionListener(evt -> executeDataUpdates());
        backBtn.addActionListener(evt -> {
            mainMenu.refreshStatisticsSummary();
            mainMenu.setVisible(true);
            this.dispose();
        });
    }

    private void populateIdComboBox() {
        searchIdCombo.removeAllItems();
        for (Employee emp : gym.getEmployees()) {
            searchIdCombo.addItem(emp.getStaffId() + " - " + emp.getFirstName() + " " + emp.getLastName());
        }
    }

    private void toggleInputState(boolean state) {
        fNameTxt.setEnabled(state);
        lNameTxt.setEnabled(state);
        addressTxt.setEnabled(state);
        phoneTxt.setEnabled(state);
        salaryTxt.setEnabled(state);
        saveBtn.setEnabled(state);
    }

    private void executeProfileLookup() {
        String selectedString = (String) searchIdCombo.getSelectedItem();
        if (selectedString == null) {
            JOptionPane.showMessageDialog(this, "No profiles are registered in the system registry.", "Registry Empty", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Extract ID by splitting at the hyphen
        int lookupId = Integer.parseInt(selectedString.split(" - ")[0]);
        Employee emp = gym.findEmployeeById(lookupId);
        if (emp == null) {
            typeStatusLbl.setText("[No Profile Context Loaded]");
            typeStatusLbl.setForeground(Color.GRAY);
            toggleInputState(false);
            return;
        }

        activeTarget = emp;
        fNameTxt.setText(emp.getFirstName());
        lNameTxt.setText(emp.getLastName());
        addressTxt.setText(emp.getAddress());
        phoneTxt.setText(emp.getPhone());
        salaryTxt.setText(String.valueOf(emp.getSalary()));

        if (emp instanceof PersonalTrainer) {
            typeStatusLbl.setText("PERSONAL TRAINER");
            typeStatusLbl.setForeground(new Color(21, 101, 192));
        } else {
            typeStatusLbl.setText("STANDARD STAFF EMPLOYEE");
            typeStatusLbl.setForeground(new Color(55, 71, 79));
        }

        toggleInputState(true);
    }

    private void executeDataUpdates() {
        if (activeTarget == null) return;
        try {
            String fName = fNameTxt.getText().trim();
            String lName = lNameTxt.getText().trim();
            double salaryValue = Double.parseDouble(salaryTxt.getText().trim());

            if (fName.isEmpty() || lName.isEmpty()) {
                throw new IllegalArgumentException("Name registration values cannot consist of empty parameters.");
            }

            GymSystem.validateName(fName, "First name");
            GymSystem.validateName(lName, "Last name");
            GymSystem.validateAddress(addressTxt.getText().trim());
            GymSystem.validatePhoneNumber(phoneTxt.getText().trim());

            activeTarget.setFirstName(fName);
            activeTarget.setLastName(lName);
            activeTarget.setAddress(addressTxt.getText().trim());
            activeTarget.setPhone(phoneTxt.getText().trim());
            activeTarget.setSalary(salaryValue);

            JOptionPane.showMessageDialog(this, "Modifications saved successfully.", "System Updated", JOptionPane.INFORMATION_MESSAGE);
            populateIdComboBox(); // Refresh combo box box to show updated name text instantly

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
        }
    }
}
