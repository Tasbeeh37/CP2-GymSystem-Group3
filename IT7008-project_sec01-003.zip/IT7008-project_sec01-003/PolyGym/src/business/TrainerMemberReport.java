package business;

import java.util.ArrayList;

/**
 * Generates a readable member list for a selected trainer.
 * @author Tasbeeh
 */
public class TrainerMemberReport {
    public static String buildList(GymSystem gym, int trainerId) {
        ArrayList<Member> members = gym.getMembersAssignedToTrainer(trainerId);
        if (members.isEmpty()) {
            return "No members are currently assigned to trainer ID " + trainerId + ".";
        }

        StringBuilder builder = new StringBuilder();
        builder.append("Trainer ID: ").append(trainerId).append("\n");
        builder.append("Assigned members:\n");
        for (Member member : members) {
            builder.append("- ID ").append(member.getMemberId())
                   .append(" | ")
                   .append(member.getFirstName())
                   .append(' ')
                   .append(member.getLastName())
                   .append('\n');
        }
        return builder.toString();
    }
}
